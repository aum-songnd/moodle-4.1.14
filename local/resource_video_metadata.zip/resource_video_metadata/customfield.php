<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Manage activity modules custom fields
 *
 * @package    local_resource_video_metadata
 * @copyright  2020 Daniel Neis Araujo
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

require_once(__DIR__ . '/../../config.php');
require_once($CFG->libdir . '/adminlib.php');

$action = optional_param('action', '', PARAM_ALPHA);

admin_externalpage_setup('local_resource_video_metadata_customfield');

$handler = \local_resource_video_metadata\customfield\mod_handler::create();

if ($action === 'init') {
    require_sesskey();
    require_capability('moodle/course:configurecustomfields', context_system::instance());

    global $DB;

    $component = $handler->get_component();
    $area      = $handler->get_area();
    $itemid    = $handler->get_itemid();

    $categoryname = 'video_metadata';

    // Tạo / lấy category.
    $categoryrecord = $DB->get_record('customfield_category', [
        'component' => $component,
        'area'      => $area,
        'itemid'    => $itemid,
        'name'      => $categoryname,
    ]);

    if ($categoryrecord) {
        $category = \core_customfield\category_controller::create(
            $categoryrecord->id,
            null,
            $handler
        );
    } else {
        $record = (object)[
            'name'        => $categoryname,
            'description' => '',
            'sortorder'   => 0,
        ];

        $category = \core_customfield\category_controller::create(
            0,
            $record,
            $handler
        );

        \core_customfield\api::save_category($category);
    }

    // ====== FIELD 1: duration (text) ======
    $fieldshortname = 'duration';

    $fieldrecord = $DB->get_record('customfield_field', [
        'shortname'  => $fieldshortname,
        'categoryid' => $category->get('id'),
    ]);

    if (!$fieldrecord) {
        $fielddata = (object)[
            'shortname'   => $fieldshortname,
            'name'        => 'Duration',
            'description' => '',
            'type'        => 'text',
            'categoryid'  => $category->get('id'),
            'sortorder'   => 0,
            'configdata'  => json_encode([]),
        ];

        $field = \core_customfield\field_controller::create(
            0,
            $fielddata,
            $category
        );

        \core_customfield\api::save_field_configuration($field, $fielddata);
    }

    $url = new moodle_url('/local/resource_video_metadata/customfield.php', [
        'categoryid' => $category->get('id'),
    ]);

    redirect(
        $url,
        get_string('initdone', 'local_resource_video_metadata'),
        null,
        \core\output\notification::NOTIFY_SUCCESS
    );
}

$output = $PAGE->get_renderer('core_customfield');
$outputpage = new \core_customfield\output\management($handler);

echo $output->header(),
     $output->heading(new lang_string('pluginname', 'local_resource_video_metadata')),
     $output->render($outputpage),
     $output->footer();