<?php
defined('MOODLE_INTERNAL') || die();

$functions = $functions ?? [];
$services  = $services ?? [];

// Đăng ký hàm webservice: lấy danh sách video theo course.
$functions['local_resource_video_metadata_get_course_videos'] = [
    'classname'   => 'local_resource_video_metadata\external',
    'methodname'  => 'get_course_videos',
    'classpath'   => '',
    'description' => 'Get list of video resources in a course with duration from customfield "duration".',
    'type'        => 'read',
    'capabilities'=> 'moodle/course:view',
    'ajax'        => true,
    'services' => [MOODLE_OFFICIAL_MOBILE_SERVICE]
];

// Service riêng (tùy chọn, để sau dùng cho token/app).
$services['local_resource_video_metadata_services'] = [
    'functions'      => [
        'local_resource_video_metadata_get_course_videos',
    ],
    'restrictedusers'=> 0,
    'enabled'        => 1,
    'shortname'      => 'local_resource_video_metadata_services',
];