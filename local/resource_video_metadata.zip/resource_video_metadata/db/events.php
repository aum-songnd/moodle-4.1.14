<?php
defined('MOODLE_INTERNAL') || die();

$observers = [
    [
        'eventname' => '\core\event\course_module_created',
        'callback'  => '\local_resource_video_metadata\observer::module_created',
        'priority' => 1000,
        'internal' => false,
    ],
    [
        'eventname' => '\core\event\course_module_updated',
        'callback'  => '\local_resource_video_metadata\observer::module_updated',
        'priority' => 1000,
        'internal' => false,
    ],
];