<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * This adds the custom fields management page.
 *
 * @package     local_resource_video_metadata
 * @copyright   2020 Daniel Neis Araujo <daniel@adapta.online>
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die;
if ($hassiteconfig) { // Needs this condition or there is error on login page.

    $ADMIN->add('localplugins', new admin_category('local_resource_video_metadata',
        get_string('pluginname', 'local_resource_video_metadata')));

    $ADMIN->add('local_resource_video_metadata',
        new admin_externalpage(
            'local_resource_video_metadata_customfield',
            new lang_string('customfields', 'local_resource_video_metadata'),
            $CFG->wwwroot . '/local/resource_video_metadata/customfield.php',
            ['moodle/course:configurecustomfields']
        )
    );

    $setingpage = new admin_settingpage('local_resource_video_metadata_settingpage',get_string('settings'));

    if ($ADMIN->fulltree) {
        $url = new moodle_url('/local/resource_video_metadata/customfield.php', [
            'action'  => 'init',     
            'sesskey' => sesskey(),
        ]);
        $formhtml = html_writer::link(
            $url,
            get_string('initbutton', 'local_resource_video_metadata'),
            ['class' => 'btn btn-primary']
        );

        $setingpage->add(new admin_setting_heading('local_resource_video_metadata_initheading',
            get_string('initbutton', 'local_resource_video_metadata'),
            $formhtml
        ));
    }

    $ADMIN->add('local_resource_video_metadata', $setingpage);
}