<?php
namespace local_resource_video_metadata;

defined('MOODLE_INTERNAL') || die();

use external_api;
use external_function_parameters;
use external_multiple_structure;
use external_single_structure;
use external_value;

use context_course;
use context_module;
use moodle_url;

use local_resource_video_metadata\customfield\mod_handler;
use core_customfield\api;

/**
 * External functions cho local_resource_video_metadata.
 *
 * @package   local_resource_video_metadata
 */
class external extends external_api {

    /**
     * Định nghĩa tham số đầu vào: courseid.
     */
    public static function get_course_videos_parameters(): external_function_parameters {
        return new external_function_parameters([
            'courseid' => new external_value(PARAM_INT, 'Course ID', VALUE_REQUIRED),
        ]);
    }

    public static function get_course_videos(int $courseid): array {
        global $DB;

        // Validate tham số.
        $params = self::validate_parameters(
            self::get_course_videos_parameters(),
            ['courseid' => $courseid]
        );
        $courseid = (int) $params['courseid'];

        // Lấy course + context.
        $course = get_course($courseid);
        $coursecontext = context_course::instance($courseid);

        self::validate_context($coursecontext);
        require_login($course);

        // Lấy danh sách resource trong course có bản ghi video (local_resource_video_md).
        $sql = "SELECT
                    cm.id AS cmid,
                    r.id  AS resourceid,
                    r.name
                FROM {course_modules} cm
                JOIN {modules} m
                     ON m.id = cm.module
                JOIN {resource} r
                     ON r.id = cm.instance
                JOIN {local_resource_video_md} v
                     ON v.resource_instance_id = r.id
                WHERE cm.course = :courseid
                  AND m.name = :modname
                  AND cm.deletioninprogress = 0";

        $records = $DB->get_records_sql($sql, [
            'courseid' => $courseid,
            'modname'  => 'resource',
        ]);

        $handler = mod_handler::create();
        $result  = [];

        foreach ($records as $rec) {
            $cmid = (int) $rec->cmid;

            // ---- Lấy duration từ customfield "duration" ----.
            $duration = 0;

            // Lấy các field áp dụng cho cmid này.
            $editablefields = $handler->get_editable_fields($cmid);
            $datarecords    = api::get_instance_fields_data($editablefields, $cmid);

            foreach ($datarecords as $data) {
                /** @var \core_customfield\data_controller $data */
                $field = $data->get_field();

                if ($field->get('shortname') === 'duration') {
                    $value = $data->get('intvalue');

                    if ($value === null || $value === '') {
                        $value = $data->get('value');
                        if ($value === null || $value === '') {
                            $value = $data->get('charvalue');
                        }
                    }

                    $duration = (int) $value;
                    break;
                }
            }

            if ($duration < 0) {
                $duration = 0;
            }

            // URL xem resource.
            $url = (new moodle_url('/mod/resource/view.php', ['id' => $cmid]))->out(false);

            // Format name theo context module cho đẹp.
            $cmcontext = context_module::instance($cmid);
            $name = format_string($rec->name, true, ['context' => $cmcontext]);

            $result[] = [
                'cmid'       => $cmid,
                'resourceid' => (int) $rec->resourceid,
                'name'       => $name,
                'url'        => $url,
                'duration'   => $duration,
            ];
        }

        return $result;
    }

    /**
     * Định nghĩa cấu trúc dữ liệu trả về.
     */
    public static function get_course_videos_returns(): external_multiple_structure {
        return new external_multiple_structure(
            new external_single_structure([
                'cmid' => new external_value(PARAM_INT, 'Course module ID'),
                'resourceid' => new external_value(PARAM_INT, 'Resource instance ID'),
                'name' => new external_value(PARAM_TEXT, 'Resource name'),
                'url' => new external_value(PARAM_URL, 'Resource view URL'),
                'duration' => new external_value(PARAM_INT, 'Video duration in seconds'),
            ])
        );
    }
}