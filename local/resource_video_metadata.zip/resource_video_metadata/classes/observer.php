<?php
namespace local_resource_video_metadata;

defined('MOODLE_INTERNAL') || die();

use local_resource_video_metadata\customfield\mod_handler;
use core_customfield\api;

/**
 * Event observer cho local_resource_video_metadata.
 *
 * @package    local_resource_video_metadata
 */
class observer {

    /**
     * Khi tạo course module (resource).
     *
     * @param \core\event\course_module_created $event
     */
    public static function module_created(\core\event\course_module_created $event) : void {
        // Chỉ xử lý cho mod_resource.
        if (empty($event->other['modulename']) || $event->other['modulename'] !== 'resource') {
            return;
        }

        $cmid = (int) $event->objectid;
        if (empty($cmid)) {
            return;
        }

        self::handle_resource_change($cmid);
    }

    public static function module_updated(\core\event\course_module_updated $event) : void {
        // Chỉ xử lý cho mod_resource.
        if (empty($event->other['modulename']) || $event->other['modulename'] !== 'resource') {
            return;
        }

        $cmid = (int) $event->objectid;
        if (empty($cmid)) {
            return;
        }

        self::handle_resource_change($cmid);
    }

    protected static function handle_resource_change(int $cmid): void {
        global $DB;

        // Lấy course module. IGNORE_MISSING để tránh exception nếu cm đã bị xóa.
        $cm = get_coursemodule_from_id('resource', $cmid, 0, false, IGNORE_MISSING);
        if (!$cm) {
            return;
        }

        // Lấy instance của resource.
        $resource = $DB->get_record('resource', ['id' => $cm->instance]);
        if (!$resource) {
            return;
        }

        $context = \context_module::instance($cm->id);
        $fs = get_file_storage();

        // Lấy tất cả file trong area content của resource.
        $files = $fs->get_area_files(
            $context->id,
            'mod_resource',
            'content',
            0,
            'sortorder, itemid, filepath, filename',
            false // false => bỏ file thư mục giả (.).
        );

        // Tìm main video (file đầu tiên có mimetype video/*).
        $currentvideo = null;
        foreach ($files as $file) {
            if (strpos($file->get_mimetype(), 'video/') === 0) {
                $currentvideo = $file;
                break;
            }
        }

        // Bản ghi hash cũ trong DB (nếu có).
        $record = $DB->get_record('local_resource_video_md', [
            'resource_instance_id' => $resource->id,
        ]);

        $changed = false;

        // 1) Không còn main video.
        if ($currentvideo === null) {
            if ($record) {
                // Trước đó có, giờ không còn => thay đổi.
                $DB->delete_records('local_resource_video_md', ['id' => $record->id]);
                $changed = true;
            }
        } else {
            // 2) Đang có main video.
            $currenthash = $currentvideo->get_contenthash();

            if (!$record) {
                // Lần đầu có main video.
                $new = (object)[
                    'resource_instance_id' => $resource->id,
                    'video_hash'           => $currenthash,
                    'timecreated'          => time(),
                    'timemodified'         => time(),
                ];
                $DB->insert_record('local_resource_video_md', $new);
                $changed = true;
            } else if ($record->video_hash !== $currenthash) {
                // Hash khác => đổi video.
                $record->video_hash   = $currenthash;
                $record->timemodified = time();
                $DB->update_record('local_resource_video_md', $record);
                $changed = true;
            }
            // Nếu có record và hash giống nhau => không thay đổi.
        }

        if (!$changed) {
            return;
        }

        // 3. Nếu không còn video -> clear duration và dừng.
        if ($currentvideo === null) {
            self::save_duration_to_customfield($cm->id, null);
            return;
        }

        $durationseconds = self::get_video_duration_ffmpeg($currentvideo);
        self::save_duration_to_customfield($cm->id, $durationseconds);

    }

   /**
     * Tính thời lượng video bằng ffmpeg, trả về giây (float) hoặc null nếu lỗi.
     */
    protected static function get_video_duration_ffmpeg(\stored_file $file): ?float {
        global $CFG;

        $contenthash = $file->get_contenthash();

        $path = $CFG->dataroot . '/filedir/' .
            substr($contenthash, 0, 2) . '/' .
            substr($contenthash, 2, 2) . '/' .
            $contenthash;

        if (!file_exists($path)) {
            return null;
        }

        $ffmpeg = 'ffmpeg'; // Nếu cần thì đổi thành đường dẫn tuyệt đối, ví dụ: /usr/bin/ffmpeg.

        $cmd = $ffmpeg . ' -i ' . escapeshellarg($path) . ' 2>&1';
        $output = @shell_exec($cmd);

        if (empty($output)) {
            return null;
        }

        if (!preg_match('/Duration:\s*(\d{2}):(\d{2}):(\d{2}\.\d+)/', $output, $matches)) {
            return null;
        }

        $hours   = (int) $matches[1];
        $minutes = (int) $matches[2];
        $seconds = (float) $matches[3];

        return $hours * 3600 + $minutes * 60 + $seconds;
    }

    protected static function save_duration_to_customfield(int $cmid, ?float $durationseconds): void {
        // Handler customfield của plugin (chung plugin với observer).
        $handler = mod_handler::create();

        // Lấy các field có thể chỉnh sửa cho cmid này.
        $editablefields = $handler->get_editable_fields($cmid);

        // Lấy data_controller cho từng field.
        $records = api::get_instance_fields_data($editablefields, $cmid);

        // Chuẩn bị giá trị số giây (nguyên).
        $secondsint = null;
        $secondstext = '';

        if (!empty($durationseconds) && $durationseconds > 0) {
            $secondsint  = (int) round($durationseconds);
            $secondstext = (string) $secondsint;
        }

        foreach ($records as $data) {
            /** @var \core_customfield\data_controller $data */
            $field = $data->get_field();

            if ($field->get('shortname') === 'duration') {
                if ($secondsint === null) {
                    // Clear field nếu không có duration hợp lệ.
                    $data->set('intvalue', null);
                    $data->set('charvalue', '');
                    $data->set('value', '');
                } else {
                    // Lưu tất cả theo đơn vị giây.
                    $data->set('intvalue', $secondsint);
                    $data->set('charvalue', $secondstext);
                    $data->set('value', $secondstext);
                }
                $data->save();
                break;
            }
        }
    }
}